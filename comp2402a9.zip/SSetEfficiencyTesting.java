package comp2402a9;
import ods.ScapegoatTree;
import ods.SkiplistSSet;
import ods.Treap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Random;

import ods.RedBlackTree;

public class SSetEfficiencyTesting {


	public static void main(String args[]) { 
		SkiplistSSet<String>	skiplist 	= new SkiplistSSet<String>();
		ScapegoatTree<String> 	scapegoat	= new ScapegoatTree<String>();
		Treap<String>			treap 		= new Treap<String>();
		RedBlackTree<String> 	redblack 	= new RedBlackTree<String>();
		
		
		Integer[] dataSizes = {10,100,1000,10000,100000,1000000,1000,2000,3000,4000,5000,6000};
		for(int q =0; q<12; q++) {
			ArrayList<String> testData = new ArrayList<String>();
			ArrayList<String> randomData = new ArrayList<String>();
			ArrayList<String> linearData = new ArrayList<String>();
			ArrayList<String> repetitiveData = new ArrayList<String>();
			ArrayList<String> nonRepetitiveRandomData = new ArrayList<String>();
			Hashtable<String,Integer> helperTable = new Hashtable<String,Integer>();
			testData.clear();
			
			long start, stop;
			Random r = new Random();
			int low = 0;
			int high = 2147483647;
			int repetitiveHigh = dataSizes[q]/2;
		
			for(int i= 0; i<dataSizes[q]; i++) {
				randomData.add(Integer.toString((r.nextInt(high-low) + low)));
				linearData.add(Integer.toString(i));
				repetitiveData.add(Integer.toString((r.nextInt(repetitiveHigh-low) + low)));	
			}
			while(helperTable.size() != dataSizes[q]) {
				helperTable.put(Integer.toString((r.nextInt(high-low) + low)), 1);
			}
			nonRepetitiveRandomData.addAll(helperTable.keySet());
			for(int i = 0; i<4; i++) {
				if(i == 0) {
					testData = randomData;
					System.out.println("********Testing for Random Data*********");
				}
				if(i == 1) {
					testData = linearData;
					System.out.println("********Testing for Linear Data*********");
				}
				if(i == 2) {
					testData = repetitiveData;
					System.out.println("********Testing for Repetitive Data*********");
				}
				if(i == 3) {
					testData = nonRepetitiveRandomData;
					System.out.println("********Testing for Non-Repetitive Random Data*********");
				}
		
				System.out.println("Data Set Size:"+testData.size());
			
//ADD TEST
				start = System.nanoTime();
				for(String s: testData) {skiplist.add(s);}
				stop = System.nanoTime();
				System.out.println(  1e-9 * (stop - start));
		
				start = System.nanoTime();
				for(String s: testData) {scapegoat.add(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
		
				start = System.nanoTime();
				for(String s: testData) {treap.add(s);}
				stop = System.nanoTime();
				System.out.println(  1e-9 * (stop - start));
		
				start = System.nanoTime();
				for(String s: testData) {redblack.add(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
			
				System.out.println("");
				
				System.out.println("SkipList size:"+skiplist.size());
				System.out.println("Scapegoat Size:"+scapegoat.size());
				System.out.println("Treap Size:"+treap.size());
				System.out.println("RedBlack Size:"+redblack.size());
				System.out.println("");
				
				
//REDUNDANT ADD TEST
				start = System.nanoTime();
				for(String s: testData) {skiplist.add(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
			
				start = System.nanoTime();
				for(String s: testData) {scapegoat.add(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
							
				start = System.nanoTime();
				for(String s: testData) {treap.add(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
				
				start = System.nanoTime();
				for(String s: testData) {redblack.add(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
				System.out.println("");	
//FIND TEST
				start = System.nanoTime();
				for(String s: testData) {skiplist.find(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
				
				start = System.nanoTime();
				for(String s: testData) {scapegoat.find(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));

				start = System.nanoTime();
				for(String s: testData) {treap.find(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));

				start = System.nanoTime();
				for(String s: testData) {redblack.find(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
				System.out.println("");	
//REMOVE TEST
				start = System.nanoTime();
				for(String s: testData) {skiplist.remove(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
		
				start = System.nanoTime();
				for(String s: testData) {if(scapegoat.size() != 1) {scapegoat.remove(s);}}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
				
				start = System.nanoTime();
				for(String s: testData) {treap.remove(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
					
				start = System.nanoTime();
				for(String s: testData) {redblack.remove(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
				System.out.println("");
//REMOVE IN SORTED TEST	
				for(String s: testData) {skiplist.add(s);scapegoat.add(s);treap.add(s);redblack.add(s);}
				Collections.sort(testData);
				
				start = System.nanoTime();
				for(String s: testData) {skiplist.remove(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
		
				start = System.nanoTime();
				for(String s: testData) {if(scapegoat.size() != 1) {scapegoat.remove(s);}}
				stop = System.nanoTime();
				System.out.println(1e-9 * (stop - start));
				
				start = System.nanoTime();
				for(String s: testData) {treap.remove(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
					
				start = System.nanoTime();
				for(String s: testData) {redblack.remove(s);}
				stop = System.nanoTime();
				System.out.println( 1e-9 * (stop - start));
				System.out.println("");
				
			
			
				
				/*
				System.out.println("SkipList size:"+skiplist.size());
				System.out.println("Scapegoat Size:"+scapegoat.size());
				System.out.println("Treap Size:"+treap.size());
				System.out.println("RedBlack Size:"+redblack.size());
				System.out.println("");
				*/
				
			}
		}
	}
}
